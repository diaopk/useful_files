/* lower limit - 200,010 posts */
select count(*) from posts where posts.ViewCoddunt > 28465

/* 1st interval 49,997 posts */
select count(*) from posts where posts.viewCount > 28464 and posts.ViewCount < 36444;

/* 2nd interval 50,001 posts */
select count(*) from posts where posts.viewCount > 36444 and posts.ViewCount < 50821;

/* 3rd  interval 50,000 posts */
select count(*) from posts where posts.ViewCount > 50821 and posts.ViewCount < 86334;

/* 4th  interval 49,997 posts */
select count(*) from posts where posts.ViewCount > 86334;
